"use client";

import { FormEvent, useState } from "react";

const services = [
  {
    title: "Strona internetowa",
    text: "Nowoczesna, szybka i dopasowana do Twojej firmy oraz klientów.",
    icon: "◎",
  },
  {
    title: "Domena",
    text: "Pomagam w zakupie domeny lub podpięciu obecnej.",
    icon: "▣",
  },
  {
    title: "Uruchomienie",
    text: "Zajmuję się całą konfiguracją i uruchomieniem strony.",
    icon: "✦",
  },
  {
    title: "Utrzymanie",
    text: "Opieka techniczna, aktualizacje i bezpieczeństwo.",
    icon: "◇",
  },
  {
    title: "Aktualizacje",
    text: "Drobne zmiany tekstów, zdjęć, cennika i oferty bez Twojego wysiłku.",
    icon: "✎",
  },
  {
    title: "Wsparcie",
    text: "Szybki kontakt i pomoc, kiedy tylko jej potrzebujesz.",
    icon: "☏",
  },
];

const steps = [
  {
    title: "Rozmowa",
    text: "Poznaję Twoją firmę, potrzeby i cele.",
  },
  {
    title: "Projekt",
    text: "Tworzę projekt strony dopasowany do Ciebie.",
  },
  {
    title: "Akceptacja",
    text: "Wprowadzam poprawki i dopracowujemy detale.",
  },
  {
    title: "Uruchomienie",
    text: "Podpinam domenę i publikuję stronę.",
  },
  {
    title: "Opieka",
    text: "Zapewniam wsparcie i aktualizacje.",
  },
];

const projects = [
  {
    name: "Kowalski Barber",
    image: "/realizacja-barber.png",
  },
  {
    name: "Bella Beauty",
    image: "/realizacja-beauty.png",
  },
  {
    name: "GreenBite Restauracja",
    image: "/realizacja-gastro.png",
  },
];

export default function Home() {
  const [sent, setSent] = useState(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const form = event.currentTarget;
    const data = new FormData(form);

    const name = String(data.get("name") || "");
    const email = String(data.get("email") || "");
    const company = String(data.get("company") || "");
    const phone = String(data.get("phone") || "");
    const message = String(data.get("message") || "");

    const subject = encodeURIComponent("Zapytanie o stronę internetową - Luminso");
    const body = encodeURIComponent(
      `Imię i nazwisko: ${name}\nE-mail: ${email}\nFirma: ${company}\nTelefon: ${phone}\n\nWiadomość:\n${message}`
    );

    window.location.href = `mailto:kontakt@luminso.pl?subject=${subject}&body=${body}`;
    setSent(true);
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#05070d] text-white">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_20%_5%,rgba(124,58,237,0.2),transparent_28%),radial-gradient(circle_at_85%_35%,rgba(37,99,235,0.12),transparent_30%),linear-gradient(180deg,#05070d,#03040a)]" />

      <div className="border-b border-white/10 bg-[#05070d]">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-6 py-3 text-xs text-zinc-300 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-violet-600 px-2 py-0.5 text-white">✦</span>
            Tworzymy nowoczesne strony internetowe dla lokalnych firm
          </div>
          <div className="flex flex-wrap gap-5">
            <span>Szybki kontakt</span>
            <span>+48 123 456 789</span>
            <span>kontakt@luminso.pl</span>
          </div>
        </div>
      </div>

      <header className="relative z-20 border-b border-white/10 bg-[#05070d]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-7">
          <a href="#" className="text-3xl font-black tracking-tight">
            lumin<span className="text-violet-500">so.</span>
          </a>

          <nav className="hidden items-center gap-10 text-sm font-semibold text-white/85 md:flex">
            <a href="#oferta" className="transition hover:text-violet-300">
              Oferta
            </a>
            <a href="#realizacje" className="transition hover:text-violet-300">
              Realizacje
            </a>
            <a href="#proces" className="transition hover:text-violet-300">
              Proces
            </a>
            <a href="#kontakt" className="transition hover:text-violet-300">
              Kontakt
            </a>
          </nav>

          <a
            href="#kontakt"
            className="rounded-xl bg-violet-600 px-6 py-3 text-sm font-bold shadow-lg shadow-violet-600/20 transition hover:bg-violet-500"
          >
            Zapytaj o wycenę →
          </a>
        </div>
      </header>

      <section className="relative z-10 mx-auto grid max-w-7xl items-center gap-12 px-6 pb-16 pt-14 md:grid-cols-[0.92fr_1.08fr] md:pt-20">
        <div>
          <h1 className="max-w-3xl text-5xl font-black leading-[1.05] tracking-tight md:text-7xl">
            Nowoczesne strony dla lokalnych firm, które{" "}
            <span className="bg-gradient-to-r from-violet-400 to-indigo-400 bg-clip-text text-transparent">
              przyciągają klientów
            </span>
          </h1>

          <p className="mt-7 max-w-xl text-xl leading-9 text-zinc-300">
            Projekt, domena, uruchomienie i opieka w jednym miejscu. Ty
            skupiasz się na swoim biznesie — my zajmujemy się resztą.
          </p>

          <div className="mt-7 grid gap-3 text-zinc-300">
            {[
              "Nowoczesny design, który buduje zaufanie",
              "Domena, podpięcie i uruchomienie strony",
              "Utrzymanie techniczne i aktualizacje",
              "Wsparcie, kiedy tego potrzebujesz",
            ].map((item) => (
              <div key={item} className="flex items-center gap-3">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-violet-600 text-xs">
                  ✓
                </span>
                <span>{item}</span>
              </div>
            ))}
          </div>

          <div className="mt-9 flex flex-col gap-4 sm:flex-row">
            <a
              href="#realizacje"
              className="rounded-xl bg-violet-600 px-7 py-4 text-center text-sm font-bold shadow-lg shadow-violet-600/25 transition hover:bg-violet-500"
            >
              Zobacz realizacje →
            </a>
            <a
              href="#kontakt"
              className="rounded-xl border border-white/20 px-7 py-4 text-center text-sm font-bold transition hover:bg-white/10"
            >
              Zapytaj o wycenę →
            </a>
          </div>
        </div>

        <div className="relative">
          <div className="absolute -inset-8 rounded-[3rem] bg-violet-600/20 blur-3xl" />
          <img
            src="/luminso-hero-preview.png"
            alt="Podgląd strony Bella Beauty"
            className="relative w-full rounded-[2rem] border border-white/10 shadow-2xl shadow-black/60"
          />
        </div>
      </section>

      <section id="oferta" className="relative z-10 mx-auto max-w-7xl px-6 py-14">
        <div className="rounded-2xl border border-white/10 bg-white/[0.025] p-6 md:p-9">
          <div className="grid gap-5 md:grid-cols-3 lg:grid-cols-6">
            {services.map((service) => (
              <div key={service.title} className="p-3">
                <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-violet-600/20 text-4xl text-violet-400">
                  {service.icon}
                </div>
                <h3 className="font-bold">{service.title}</h3>
                <p className="mt-4 text-sm leading-7 text-zinc-400">
                  {service.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="proces" className="relative z-10 mx-auto max-w-7xl px-6 py-12">
        <h2 className="text-center text-3xl font-black tracking-tight md:text-4xl">
          Jak wygląda współpraca?
        </h2>

        <div className="mt-12 grid gap-8 md:grid-cols-5">
          {steps.map((step, index) => (
            <div key={step.title} className="relative text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-violet-600 text-xl font-black shadow-lg shadow-violet-600/25">
                {index + 1}
              </div>
              <h3 className="mt-5 font-bold">{step.title}</h3>
              <p className="mx-auto mt-3 max-w-40 text-sm leading-6 text-zinc-400">
                {step.text}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section id="realizacje" className="relative z-10 mx-auto max-w-7xl px-6 py-12">
        <div className="flex items-end justify-between gap-6">
          <h2 className="text-3xl font-black tracking-tight md:text-4xl">
            Realizacje
          </h2>
          <a href="#kontakt" className="hidden text-sm font-semibold text-violet-400 hover:text-violet-300 md:block">
            Zobacz wszystkie realizacje →
          </a>
        </div>

        <div className="mt-7 grid gap-5 md:grid-cols-3">
          {projects.map((project) => (
            <article
              key={project.name}
              className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.035]"
            >
              <img
                src={project.image}
                alt={`Zrzut ekranu strony ${project.name}`}
                className="aspect-[16/10] w-full object-cover"
              />
              <div className="p-5">
                <h3 className="font-bold">{project.name}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="kontakt" className="relative z-10 mx-auto max-w-7xl px-6 pb-14 pt-4">
        <div className="grid gap-8 rounded-3xl border border-white/10 bg-white/[0.035] p-8 md:grid-cols-[0.85fr_1.15fr] md:p-10">
          <div>
            <h2 className="max-w-xl text-4xl font-black leading-tight tracking-tight md:text-5xl">
              Gotowy na stronę, która pracuje na{" "}
              <span className="text-violet-400">Twój biznes?</span>
            </h2>
            <p className="mt-5 text-zinc-300">
              Napisz do mnie i otrzymaj darmową wycenę.
            </p>

            <div className="mt-8 flex flex-wrap gap-5 text-sm text-zinc-300">
              <span>✓ Bez zobowiązań</span>
              <span>✓ Odpowiem w 24h</span>
              <span>✓ Darmowa wycena</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="grid gap-4">
            <div className="grid gap-4 md:grid-cols-2">
              <input
                required
                name="name"
                placeholder="Imię i nazwisko"
                className="rounded-lg border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none transition placeholder:text-zinc-500 focus:border-violet-500"
              />
              <input
                required
                type="email"
                name="email"
                placeholder="E-mail"
                className="rounded-lg border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none transition placeholder:text-zinc-500 focus:border-violet-500"
              />
              <input
                name="company"
                placeholder="Nazwa firmy (opcjonalnie)"
                className="rounded-lg border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none transition placeholder:text-zinc-500 focus:border-violet-500"
              />
              <input
                name="phone"
                placeholder="Telefon (opcjonalnie)"
                className="rounded-lg border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none transition placeholder:text-zinc-500 focus:border-violet-500"
              />
            </div>

            <textarea
              required
              name="message"
              placeholder="Napisz kilka słów o swoim projekcie..."
              rows={5}
              className="rounded-lg border border-white/10 bg-black/20 px-4 py-3 text-sm outline-none transition placeholder:text-zinc-500 focus:border-violet-500"
            />

            <button
              type="submit"
              className="rounded-lg bg-violet-600 px-7 py-4 text-sm font-bold shadow-lg shadow-violet-600/25 transition hover:bg-violet-500"
            >
              Wyślij wiadomość →
            </button>

            {sent && (
              <p className="text-sm text-violet-300">
                Otwieram program pocztowy z gotową wiadomością.
              </p>
            )}
          </form>
        </div>
      </section>

      <footer className="relative z-10 border-t border-white/10 px-6 py-8">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-5 text-sm text-zinc-500 md:flex-row md:items-center">
          <div className="text-2xl font-black text-white">
            lumin<span className="text-violet-500">so.</span>
          </div>
          <div>© 2026 Luminso. Wszelkie prawa zastrzeżone.</div>
          <div className="flex gap-5 text-zinc-400">
            <a href="#kontakt" className="hover:text-white">
              Kontakt
            </a>
            <a href="#oferta" className="hover:text-white">
              Oferta
            </a>
          </div>
        </div>
      </footer>
    </main>
  );
}
